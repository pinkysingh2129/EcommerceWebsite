function NotFound(){
    return  <div className="flex min-h-screen w-full flex-1 flex-col"> nothing found here </div>
}
export default NotFound;