function AdminOrders(){
    return <div className="w-400"> Place Orders </div>;
}
export default AdminOrders;