function AdminProduct(){
    return <div className="w-400"> Products </div>;
}
export default AdminProduct;