function AdminDashboard(){
    return <div className="w-400"> Dashboards </div>;
}
export default AdminDashboard;