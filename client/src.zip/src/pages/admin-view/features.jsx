function AdminFeatures(){
    return <div className="w-400"> featuers </div>;
}
export default AdminFeatures;