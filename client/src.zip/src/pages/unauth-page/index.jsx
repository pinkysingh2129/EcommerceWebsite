function UnauthPage(){
    return  <h1> YOu Dont Have Access To View This Page </h1>
}

export default UnauthPage;