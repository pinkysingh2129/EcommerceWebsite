function ShoppingAccount(){
    return  <div > Shopping Account </div>
}
export default ShoppingAccount;